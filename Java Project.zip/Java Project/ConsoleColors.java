// ConsoleColors.java
public class ConsoleColors {
    // Reset
    public static final String RESET = "\033[0m";

    // Regular Colors
    public static final String BLACK = "\033[0;30m";
    public static final String RED = "\033[0;31m";
    public static final String GREEN = "\033[0;32m";
    public static final String YELLOW = "\033[0;33m";
    public static final String BLUE = "\033[0;34m";
    public static final String PURPLE = "\033[0;35m";
    public static final String CYAN = "\033[0;36m";
    public static final String WHITE = "\033[0;37m";
    public static final String LIGHT_GREY = "\033[0;37m";

    // Bold Colors
    public static final String BOLD_BLACK = "\033[1;30m";
    public static final String BOLD_RED = "\033[1;31m";
    public static final String BOLD_GREEN = "\033[1;32m";
    public static final String BOLD_YELLOW = "\033[1;33m";
    public static final String BOLD_BLUE = "\033[1;34m";
    public static final String BOLD_PURPLE = "\033[1;35m";
    public static final String BOLD_CYAN = "\033[1;36m";
    public static final String BOLD_WHITE = "\033[1;37m";

    // Bright Colors
    public static final String BRIGHT_RED = "\033[0;91m";
    public static final String BRIGHT_GREEN = "\033[0;92m";
    public static final String BRIGHT_YELLOW = "\033[0;93m";
    public static final String BRIGHT_BLUE = "\033[0;94m";
    public static final String BRIGHT_PURPLE = "\033[0;95m";
    public static final String BRIGHT_CYAN = "\033[0;96m";
    public static final String BRIGHT_WHITE = "\033[0;97m";

    // Bold Bright Colors
    public static final String BOLD_BRIGHT_RED = "\033[1;91m";
    public static final String BOLD_BRIGHT_GREEN = "\033[1;92m";
    public static final String BOLD_BRIGHT_YELLOW = "\033[1;93m";
    public static final String BOLD_BRIGHT_BLUE = "\033[1;94m";
    public static final String BOLD_BRIGHT_PURPLE = "\033[1;95m";
    public static final String BOLD_BRIGHT_CYAN = "\033[1;96m";
    public static final String BOLD_BRIGHT_WHITE = "\033[1;97m";

    // Background Colors
    public static final String BG_BLACK = "\033[40m";
    public static final String BG_RED = "\033[41m";
    public static final String BG_GREEN = "\033[42m";
    public static final String BG_YELLOW = "\033[43m";
    public static final String BG_BLUE = "\033[44m";
    public static final String BG_PURPLE = "\033[45m";
    public static final String BG_CYAN = "\033[46m";
    public static final String BG_WHITE = "\033[47m";

    // Bright Background Colors
    public static final String BG_BRIGHT_BLACK = "\033[0;100m";
    public static final String BG_BRIGHT_RED = "\033[0;101m";
    public static final String BG_BRIGHT_GREEN = "\033[0;102m";
    public static final String BG_BRIGHT_YELLOW = "\033[0;103m";
    public static final String BG_BRIGHT_BLUE = "\033[0;104m";
    public static final String BG_BRIGHT_PURPLE = "\033[0;105m";
    public static final String BG_BRIGHT_CYAN = "\033[0;106m";
    public static final String BG_BRIGHT_WHITE = "\033[0;107m";

    // Underline
    public static final String UNDERLINE_BLACK = "\033[4;30m";
    public static final String UNDERLINE_RED = "\033[4;31m";
    public static final String UNDERLINE_GREEN = "\033[4;32m";
    public static final String UNDERLINE_YELLOW = "\033[4;33m";
    public static final String UNDERLINE_BLUE = "\033[4;34m";
    public static final String UNDERLINE_PURPLE = "\033[4;35m";
    public static final String UNDERLINE_CYAN = "\033[4;36m";
    public static final String UNDERLINE_WHITE = "\033[4;37m";

    // Bold Underline
    public static final String BOLD_UNDERLINE_RED = "\033[1;4;31m";
    public static final String BOLD_UNDERLINE_GREEN = "\033[1;4;32m";

    // Italic (if supported by the terminal)
    public static final String ITALIC = "\033[3m";

    // Strikethrough
    public static final String STRIKETHROUGH = "\033[9m";
}
